# PTI Parfum Website

Website landing page responsif untuk PTI Parfum, dibuat dengan HTML, CSS, Tailwind CSS CDN, dan JavaScript vanilla.

## Isi folder
- `index.html` — struktur halaman dan komponen UI.
- `style.css` — styling custom, responsive layout, animasi, modal keranjang, dan chatbot.
- `tailwind.config.js` — konfigurasi tema Tailwind.
- `script.js` — katalog produk, filter/pencarian, keranjang, form demo, animasi scroll, dan chatbot.
- `assets/` — folder untuk aset gambar tambahan.

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka folder `pti-parfum-website`.
3. Buka `index.html` di browser atau gunakan Live Server di VS Code.
4. Internet diperlukan untuk memuat Tailwind CDN dan Google Fonts.

## Kustomisasi produk
Data produk berada di array `products` pada `script.js`. Ubah nama, kategori, harga, deskripsi, dan warna botol sesuai katalog asli.

## Catatan penting
- Harga dan produk saat ini adalah contoh/demo.
- Keranjang tersimpan di `localStorage` browser, tetapi checkout belum terhubung ke payment gateway atau database.
- Form kontak belum mengirim email/pesan ke server.
- Chatbot menggunakan pencocokan kata kunci, bukan AI berbasis server.
- Sebelum dipublikasikan, isi kontak resmi dan sambungkan checkout/form ke layanan yang benar.
